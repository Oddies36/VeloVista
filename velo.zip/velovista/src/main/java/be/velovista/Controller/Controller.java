package be.velovista.Controller;

import java.beans.PropertyChangeListener;
import java.security.InvalidParameterException;
import java.util.function.Consumer;
import java.util.function.Supplier;

import be.velovista.Model.IModel;
import be.velovista.Model.PrimaryModel;
import be.velovista.View.IView;
import be.velovista.View.PrimaryView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.WindowEvent;

public class Controller {
  
    private IModel model;
    private IView view;

    public void initialize(){
        this.model = new PrimaryModel();
        this.view = new PrimaryView();
        if (PropertyChangeListener.class.isAssignableFrom(view.getClass())){
            PropertyChangeListener pcl = (PropertyChangeListener) view;            
            model.addPropertyChangeListener(pcl);
        }
        view.setController(this);
    }

    public void start(){
        this.view.launchApp();
    }


    public EventHandler<ActionEvent> generateEventHandlerAction(String action, Supplier<String[]> params){    
        Consumer<String[]> function = this.generateConsumer(action);        
        return new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                function.accept(params.get());;
            }
            
        };
    }

    private Consumer<String[]> generateConsumer(String action){
        Consumer<String[]> t;
        switch (action) {
            case "showPrincipalWindow":
                t = (x) -> this.showPrincipalWindow();
                break;
            case "showAccountCreation":
                t = (x) -> this.showAccountCreation();
                break; 
            case "checkLoginCreds":
                t = (x) -> this.checkLoginCreds(x [0], x[1]);
                break;
            case "show-velo-page":
                t = (x) -> this.getPrixVelos();
                break;
            case "show-liste-velo-class":
                t = (x) -> this.getListeVeloClassique(x [0]);
                break;
            case "creation-compte-utilisateur":
                t = (x) -> this.CreationCompteUtilisateur(x [0], x [1], x [2], x [3]);
                break;
            default:
                throw new InvalidParameterException(action + " n'existe pas.");
        }
        return t;
    }

    public EventHandler<WindowEvent> generateCloseEvent(){
        return new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                stop();
                System.exit(0);
            }
        };
    }

    public void CreationCompteUtilisateur(String nom, String Email, String mdpClaire, String mdpClaireRepeat){
        if(this.model.CreationCompteUtilisateur(nom, Email, mdpClaire, mdpClaireRepeat)){
            this.view.showPrincipalWindow();
        }
    }

    public void getListeVeloClassique(String typeVelo){
        this.model.getListeVeloClassique(typeVelo);
    }

    public void getPrixVelos(){
        this.model.getPrixVelos();
    }

    public void checkLoginCreds(String email, String enteredPassword){
        if(this.model.passwordMatch(email, enteredPassword)){
            this.view.showMainScreen();
        }
    }

    public void showAccountCreation(){
        this.view.showAccountCreation();
    }
    public void showPrincipalWindow(){
        this.view.showPrincipalWindow();
    }

    
    public void setModel(IModel model){
        this.model = model;
    }

    public void setView(IView view){
        this.view = view;
    }

    public void stop(){       
        this.view.stopApp();
    }
}
