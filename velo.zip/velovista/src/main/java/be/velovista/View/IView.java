package be.velovista.View;

import java.util.ArrayList;

import be.velovista.Controller.Controller;
import be.velovista.Model.BL.Velo;
import be.velovista.Model.BL.VeloClassique;

public interface IView {
  public void setController(Controller control);
  public void launchApp();
  public void stopApp();
  public void showMainScreen();
  public void showPrincipalWindow();
  public void showAccountCreation();
  public void showVeloCategory(ArrayList<String> listePrixTypeVelos);
  public void showListeVeloClassique(ArrayList<Velo> listeVelosClass);
}
