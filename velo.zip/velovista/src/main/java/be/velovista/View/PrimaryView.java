package be.velovista.View;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Supplier;

import be.velovista.Controller.Controller;
import be.velovista.Model.BL.Velo;
import be.velovista.Model.BL.VeloClassique;
import be.velovista.Model.BL.VeloElectrique;
import be.velovista.Model.BL.VeloEnfant;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PrimaryView extends Application implements IView, PropertyChangeListener {
    
    private static Scene scene;
    private static Stage stage;
    private Pane actualParent; 
    private Controller control;

    public void setController(Controller control) {
        this.control = control;
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        switch (evt.getPropertyName()) {
            case "retour-liste-prix-type-velos":
                if (evt.getNewValue().getClass().isAssignableFrom(ArrayList.class))
                    this.showVeloCategory((ArrayList<String>) evt.getNewValue());
                break;
            case "retour-liste-velos-class":
                if (evt.getNewValue().getClass().isAssignableFrom(ArrayList.class))
                    this.showListeVeloClassique((ArrayList<Velo>) evt.getNewValue());
            default:
                break;
        }
    }

    @Override
    public void start(Stage stage) throws IOException {
        PrimaryView.stage = stage;
        // Préparation du stage pour gérer la fermeture du programme.
        PrimaryView.stage.setOnCloseRequest(this.control.generateCloseEvent());

        // Préparation de la première fenêtre
        showPrincipalWindow();
        stage.show();
    }

    public void showPrincipalWindow(){
        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        //parent
        actualParent = new VBox();
        actualParent.setStyle("-fx-background-color: #ffffff");

        //vbox pour le titre et text en dessous
        VBox vboxTitre = new VBox();
        vboxTitre.setAlignment(Pos.CENTER);
        vboxTitre.setPadding(new Insets(20, 0, 0, 0));
        
        //vbox pour le login et mdp
        VBox vboxLoginMdp = new VBox();
        vboxLoginMdp.setAlignment(Pos.CENTER);
        vboxLoginMdp.setPadding(new Insets(150, 100, 0, 100));

        //hbox pour le text email
        HBox hboxEmailText = new HBox();

        //hbox pour le text password
        HBox hboxPasswordText = new HBox();
        hboxPasswordText.setPadding(new Insets(20, 0, 0, 0));

        //hbox pour pas de compte
        HBox hboxPasDeCompte = new HBox();
        hboxPasDeCompte.setAlignment(Pos.CENTER);
        hboxPasDeCompte.setPadding(new Insets(20, 0, 0, 0));
        


        //titre
        Label titre = new Label("Se connecter");
        titre.setStyle("-fx-font-size: 50;");
        //texte en dessous de titre
        Label textSousTitre = new Label("Entrez votre email et votre mot de passe");

        //email text
        Label emailText = new Label("E-mail");
        //email field
        TextField email = new TextField();
        email.setPromptText("E-mail");

        //password text & forgot password
        Label passwordText = new Label("Mot de passe");
        Hyperlink forgotPassword = new Hyperlink("Mot de passe oublié");

        //password field
        PasswordField password = new PasswordField();
        password.setPromptText("Mot de passe");

        //login button
        Button login = new Button("Connexion");
        setButtonStyle(login, "rond");


        Supplier<String[]> userLogin = () -> new String[] {email.getText(), password.getText()};
        login.setOnAction(control.generateEventHandlerAction("checkLoginCreds", userLogin));






        //pas de compte text & hyperlink
        Label pasDeCompte = new Label("Pas de compte?");
        Hyperlink creerCompte = new Hyperlink("S'enregistrer");
        creerCompte.setStyle("-fx-font-weight: bold");
        Supplier<String[]> supplier = () -> new String[] {""};
        creerCompte.setOnAction(control.generateEventHandlerAction("showAccountCreation", supplier));

        vboxTitre.getChildren().addAll(titre, textSousTitre);
        hboxEmailText.getChildren().addAll(emailText);
        hboxPasswordText.getChildren().addAll(passwordText, spacer, forgotPassword);
        hboxPasDeCompte.getChildren().addAll(pasDeCompte, creerCompte);
        vboxLoginMdp.getChildren().addAll(hboxEmailText, email, hboxPasswordText, password, login, hboxPasDeCompte);
        actualParent.getChildren().addAll(vboxTitre, vboxLoginMdp);

        stage.setResizable(false);
        scene = new Scene(actualParent, 500, 600);
        stage.setScene(scene);
        stage.centerOnScreen();
    }


    public void showMainScreen(){

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        //parent
        actualParent = new VBox();
        actualParent.setStyle("-fx-background-color: #ffffff");

        GridPane grid = new GridPane();

        //le logo
        Image logo = new Image(getClass().getResourceAsStream("/images/VeloVistaLogo.png"));
        ImageView viewLogo = new ImageView(logo);
        viewLogo.setFitWidth(200);
        viewLogo.setPreserveRatio(true);

        //l'image background
        Image backgroundImage = new Image(getClass().getResourceAsStream("/images/newerFaded.png"));
        ImageView viewBackgroundImage = new ImageView(backgroundImage);
        viewBackgroundImage.setFitWidth(800);
        GridPane.setMargin(viewBackgroundImage, new Insets(20, 20, 20, 20));
        viewBackgroundImage.setPreserveRatio(true);

        //span l'image sur 2 colonnes
        GridPane.setRowIndex(viewBackgroundImage, 1);
        GridPane.setColumnIndex(viewBackgroundImage, 1);
        GridPane.setColumnSpan(viewBackgroundImage, 2);

        //bouton pour voir les abonnements
        HBox hboxBoutonsAbo = new HBox();
        Button boutonAbo = new Button("Nos abonnements");
        GridPane.setMargin(hboxBoutonsAbo, new Insets(0, 0, 0, 20));
        setButtonStyle(boutonAbo, "Rect");

        //bouton pour voir les vélos
        HBox hboxBoutonVelo = new HBox();
        hboxBoutonVelo.setAlignment(Pos.CENTER_RIGHT);
        Button boutonVelo = new Button("Nos vélos");
        GridPane.setMargin(hboxBoutonVelo, new Insets(0, 20, 0, 0));
        setButtonStyle(boutonVelo, "Rect");

        //event sur bouton "nos velos"
        Supplier<String[]> supplier = () -> new String[] {""};
        boutonVelo.setOnAction(control.generateEventHandlerAction("show-velo-page", supplier));

        //vbox menu et items dans le menu
        VBox vboxMenu = new VBox();
        vboxMenu.setAlignment(Pos.CENTER);
        Button boutonProfil = new Button("Profil");
        setButtonStyle(boutonProfil, "RectRond");
        Button boutonHistorique = new Button("Mon historique");
        setButtonStyle(boutonHistorique, "RectRond");
        Button boutonCommentaires = new Button("Commentaires");
        setButtonStyle(boutonCommentaires, "RectRond");
        Button boutonDeconnexion = new Button("Déconnexion");
        setButtonStyle(boutonDeconnexion, "RectRond");

        Button notificationBouton = new Button("Notif");
        notificationBouton.setStyle("-fx-background-color: red;");
        GridPane.setMargin(notificationBouton, new Insets(0, 0, 0, 0));

        grid.add(viewLogo, 0, 0);
        grid.add(vboxMenu, 0, 1);
        grid.add(viewBackgroundImage, 1, 1);
        grid.add(hboxBoutonsAbo, 1, 2);
        grid.add(hboxBoutonVelo, 2, 2);
        grid.add(notificationBouton, 3, 0);

        grid.setGridLinesVisible(true);



        
        vboxMenu.getChildren().addAll(boutonProfil, boutonHistorique, boutonCommentaires, boutonDeconnexion);
        hboxBoutonsAbo.getChildren().addAll(boutonAbo);
        hboxBoutonVelo.getChildren().addAll(boutonVelo);
        actualParent.getChildren().addAll(grid);

        stage.setResizable(false);
        scene = new Scene(actualParent, 1200, 700);
        stage.setScene(scene);
        stage.centerOnScreen();
    }


    public void showAccountCreation(){

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        //parent
        actualParent = new VBox();
        actualParent.setStyle("-fx-background-color: #ffffff");
        

        //vbox pour le titre et text en dessous
        VBox vboxTitre = new VBox();
        vboxTitre.setAlignment(Pos.CENTER);
        vboxTitre.setPadding(new Insets(20, 0, 0, 0));

        //titre
        Label titre = new Label("Créer son compte");
        titre.setStyle("-fx-font-size: 50;");
        //texte en dessous de titre
        Label textSousTitre = new Label("Créez votre compte pour pouvoir louer un vélo en toute sécurité.");



        //vbox pour le formulaire a remplir
        VBox vboxFormulaireInscription = new VBox();
        vboxFormulaireInscription.setAlignment(Pos.CENTER);
        vboxFormulaireInscription.setPadding(new Insets(100, 100, 0, 100));

        //hbox pour le label Nom
        HBox hboxLabelNom = new HBox();
        //label nom
        Label labelNom = new Label("Nom");
        TextField fieldNom = new TextField();
        fieldNom.setPromptText("Nom");
        //hbox pour le label Email
        HBox hboxLabelEmail = new HBox();
        //label email
        Label labelEmail = new Label("Email");
        TextField fieldEmail = new TextField();
        fieldEmail.setPromptText("Email");
        //hbox pour le label password
        HBox hboxLabelPassword = new HBox();
        //label password
        Label labelPassword = new Label("Mot de passe");
        PasswordField fieldPassword = new PasswordField();
        fieldPassword.setPromptText("Mot de passe");
        //hbox pour le label password
        HBox hboxLabelPasswordRepeat = new HBox();
        //label password
        Label labelPasswordRepeat = new Label("Confirmer le mot de passe");
        PasswordField fieldPasswordRepeat = new PasswordField();
        fieldPasswordRepeat.setPromptText("Confirmez le mot de passe");

        //bouton pour creer le compte
        Button creerCompte = new Button("Créer son compte");
        setButtonStyle(creerCompte, "rond");

        Supplier<String[]> creationCompteSupplier = () -> new String[] {fieldNom.getText(), fieldEmail.getText(), fieldPassword.getText(), fieldPasswordRepeat.getText()};
        creerCompte.setOnAction(control.generateEventHandlerAction("creation-compte-utilisateur", creationCompteSupplier));

        //hbox pour message et lien retour login
        HBox hboxRetourLogin = new HBox();
        hboxRetourLogin.setAlignment(Pos.CENTER);
        hboxRetourLogin.setPadding(new Insets(20, 0, 0, 0));
        //label message retour login
        Label dejaUnCompte = new Label("Déjà client?");
        //Lien retour login
        Hyperlink retourLogin = new Hyperlink("Se connecter");
        retourLogin.setStyle("-fx-font-weight: bold");

        Supplier<String[]> supplier = () -> new String[] {""};
        retourLogin.setOnAction(control.generateEventHandlerAction("showPrincipalWindow", supplier));

        vboxTitre.getChildren().addAll(titre, textSousTitre);
        vboxFormulaireInscription.getChildren().addAll(hboxLabelNom, fieldNom, hboxLabelEmail, fieldEmail, hboxLabelPassword, fieldPassword, hboxLabelPasswordRepeat, fieldPasswordRepeat, creerCompte, hboxRetourLogin);
        hboxLabelNom.getChildren().addAll(labelNom);
        hboxLabelPassword.getChildren().addAll(labelPassword);
        hboxLabelEmail.getChildren().addAll(labelEmail);
        hboxLabelPasswordRepeat.getChildren().addAll(labelPasswordRepeat);
        hboxRetourLogin.getChildren().addAll(dejaUnCompte, retourLogin);
        actualParent.getChildren().addAll(vboxTitre, vboxFormulaireInscription);
        
        stage.setResizable(false);
        scene = new Scene(actualParent, 500, 600);
        stage.setScene(scene);
        stage.centerOnScreen();
    }


    public void showProfilePage(){

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        //parent
        actualParent = new VBox();
        actualParent.setStyle("-fx-background-color: #ffffff");

        //vbox pour le titre et text en dessous
        VBox vboxTitre = new VBox();
        vboxTitre.setAlignment(Pos.CENTER);
        vboxTitre.setPadding(new Insets(20, 0, 0, 0));

        //titre profil
        Label titreProfil = new Label("Mon profil");
        titreProfil.setStyle("-fx-font-size: 50;");

        vboxTitre.getChildren().addAll(titreProfil);
        actualParent.getChildren().addAll(vboxTitre);

        stage.setResizable(false);
        scene = new Scene(actualParent, 800, 700);
        stage.setScene(scene);
        stage.centerOnScreen();

    }


    public void showVeloCategory(ArrayList<String> listePrixTypeVelos){

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        //parent
        actualParent = new VBox();
        actualParent.setStyle("-fx-background-color: #ffffff");

        VBox content = new VBox();
        content.setAlignment(Pos.CENTER);


        Label titre = new Label("Nos vélos");
        titre.setStyle("-fx-font-size: 50;");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);

        Image imgVeloClassique = new Image(getClass().getResourceAsStream("/images/veloClassique.png"));
        ImageView viewImgVeloClassique = new ImageView(imgVeloClassique);
        viewImgVeloClassique.setFitHeight(200);
        viewImgVeloClassique.setFitWidth(200);
        Image imgVeloElectrique = new Image(getClass().getResourceAsStream("/images/veloElectrique.png"));
        ImageView viewImgVeloElectrique = new ImageView(imgVeloElectrique);
        viewImgVeloElectrique.setFitHeight(200);
        viewImgVeloElectrique.setFitWidth(200);
        Image imgVeloEnfant = new Image(getClass().getResourceAsStream("/images/veloEnfant.png"));
        ImageView viewImgVeloEnfant = new ImageView(imgVeloEnfant);
        viewImgVeloEnfant.setFitHeight(200);
        viewImgVeloEnfant.setFitWidth(200);

        GridPane.setMargin(viewImgVeloEnfant, new Insets(10, 0, 0, 0));
        GridPane.setMargin(viewImgVeloElectrique, new Insets(10, 0, 0, 0));
        

        Label descriptionVeloClassique = new Label("Vélo classique. Prix: " + listePrixTypeVelos.get(0));
        Label descriptionVeloElectrique = new Label("Vélo éléctrique. Prix: " + listePrixTypeVelos.get(1));
        Label descriptionVeloEnfant = new Label("Vélo enfant. Prix: " + listePrixTypeVelos.get(2));

        Button choisirVeloClassique = new Button("Voir les vélos classiques");
        Button choisirVeloElectrique = new Button("Voir les vélos éléctriques");
        Button choisirVeloEnfant = new Button("Voir les vélos enfants");

        GridPane.setValignment(descriptionVeloClassique, VPos.TOP);

        grid.setGridLinesVisible(true);
        grid.add(viewImgVeloClassique, 0, 0);
        grid.add(descriptionVeloClassique, 1, 0);
        grid.add(viewImgVeloElectrique, 0, 1);
        grid.add(descriptionVeloElectrique, 1, 1);
        grid.add(viewImgVeloEnfant, 0, 2);
        grid.add(descriptionVeloEnfant, 1, 2);
        grid.add(choisirVeloClassique, 2, 0);
        grid.add(choisirVeloElectrique, 2, 1);
        grid.add(choisirVeloEnfant, 2, 2);

        Supplier<String[]> supplierClass = () -> new String[] {"Classique"};
        choisirVeloClassique.setOnAction(control.generateEventHandlerAction("show-liste-velo-class", supplierClass));

        Supplier<String[]> supplierElec = () -> new String[] {"Electrique"};
        choisirVeloElectrique.setOnAction(control.generateEventHandlerAction("show-liste-velo-class", supplierElec));

        Supplier<String[]> supplierEnfant = () -> new String[] {"Enfant"};
        choisirVeloEnfant.setOnAction(control.generateEventHandlerAction("show-liste-velo-class", supplierEnfant));


        content.getChildren().addAll(titre, grid);
        actualParent.getChildren().addAll(content);

        stage.setResizable(false);
        scene = new Scene(actualParent, 1200, 700);
        stage.setScene(scene);
        stage.centerOnScreen();
    }


    public void showListeVeloClassique(ArrayList<Velo> listeVelosClass){

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button back = new Button("Retour");

        //parent
        actualParent = new VBox();
        actualParent.setStyle("-fx-background-color: #ffffff");


        TilePane listeVelos = new TilePane();
        listeVelos.setHgap(20);
        listeVelos.setVgap(20);
        listeVelos.setPrefColumns(1);
        listeVelos.setAlignment(Pos.CENTER);
        

        for(Velo velclass : listeVelosClass){
            VBox vbox = new VBox();
            Image img = new Image(velclass.getPhoto(), true);
            ImageView imgview = new ImageView();
            imgview.setImage(img);
            imgview.setFitWidth(100);
            imgview.setPreserveRatio(true);

            Label couleur = new Label("Couleur: " + velclass.getCouleur().toString());
            Label prix = new Label("Prix: " + String.valueOf(velclass.getPrix()) + "€");

            vbox.getChildren().addAll(imgview, couleur, prix);

            if(velclass instanceof VeloClassique){
                Label vitesses = new Label("Vitesses: " + velclass.getVitessesFromVelo());
                vbox.getChildren().add(vitesses);
            }
            else if(velclass instanceof VeloElectrique){
                Label vitesses = new Label("Autonomie: " + velclass.getAutonomieFromVelo() + "km");
                vbox.getChildren().add(vitesses);
            }

            listeVelos.getChildren().add(vbox);
        }

        //ObservableList<VeloClassique> obslist = FXCollections.observableArrayList(listeVelosClass);
        //ListView<VeloClassique> listeVelosClassique = new ListView<>(obslist);

        Supplier<String[]> supplier = () -> new String[] {};
        back.setOnAction(control.generateEventHandlerAction("show-velo-page", supplier));

        actualParent.getChildren().addAll(back, listeVelos);

        stage.setResizable(false);
        scene = new Scene(actualParent, 1200, 700);
        stage.setScene(scene);
        stage.centerOnScreen();
    }


    public void showListeAboDispo(){

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button back = new Button("Retour");

        //parent
        actualParent = new VBox();
        actualParent.setStyle("-fx-background-color: #ffffff");





        stage.setResizable(false);
        scene = new Scene(actualParent, 1200, 700);
        stage.setScene(scene);
        stage.centerOnScreen();

    }

    public void setButtonStyle(Button nomBouton, String type){
        switch(type){
            case "rond":
            nomBouton.setStyle("-fx-font-size: 15px; -fx-background-radius: 20; -fx-padding: 10 20 10 20; -fx-background-color: #323b6f; -fx-text-fill: white;");
            nomBouton.setPrefWidth(200);
            VBox.setMargin(nomBouton, new Insets(30, 0, 0, 0));
      
            nomBouton.setOnMouseEntered(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-background-radius: 20; -fx-padding: 10 20 10 20; -fx-background-color: #46508f; -fx-text-fill: white;"));
            nomBouton.setOnMouseExited(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-background-radius: 20; -fx-padding: 10 20 10 20; -fx-background-color: #323b6f; -fx-text-fill: white;"));
            nomBouton.setOnMousePressed(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-background-radius: 20; -fx-padding: 10 20 10 20; -fx-background-color: #1f2a50; -fx-text-fill: white;"));
            nomBouton.setOnMouseReleased(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-background-radius: 20; -fx-padding: 10 20 10 20; -fx-background-color: #323b6f; -fx-text-fill: white;"));
            break;
            case "RectRond":
            nomBouton.setStyle("-fx-font-size: 15px; -fx-background-radius: 0 20 20 0; -fx-padding: 10 20 10 20; -fx-background-color: #323b6f; -fx-text-fill: white;");
            nomBouton.setPrefWidth(200);
            VBox.setMargin(nomBouton, new Insets(30, 0, 0, 0));
      
            nomBouton.setOnMouseEntered(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-background-radius: 0 20 20 0; -fx-padding: 10 20 10 20; -fx-background-color: #46508f; -fx-text-fill: white;"));
            nomBouton.setOnMouseExited(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-background-radius: 0 20 20 0; -fx-padding: 10 20 10 20; -fx-background-color: #323b6f; -fx-text-fill: white;"));
            nomBouton.setOnMousePressed(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-background-radius: 0 20 20 0; -fx-padding: 10 20 10 20; -fx-background-color: #1f2a50; -fx-text-fill: white;"));
            nomBouton.setOnMouseReleased(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-background-radius: 0 20 20 0; -fx-padding: 10 20 10 20; -fx-background-color: #323b6f; -fx-text-fill: white;"));
            break;
            case "Rect":
            nomBouton.setStyle("-fx-font-size: 15px; -fx-padding: 10 20 10 20; -fx-background-color: #323b6f; -fx-text-fill: white;");
            nomBouton.setPrefWidth(200);
            VBox.setMargin(nomBouton, new Insets(30, 0, 0, 0));
      
            nomBouton.setOnMouseEntered(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-padding: 10 20 10 20; -fx-background-color: #46508f; -fx-text-fill: white;"));
            nomBouton.setOnMouseExited(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-padding: 10 20 10 20; -fx-background-color: #323b6f; -fx-text-fill: white;"));
            nomBouton.setOnMousePressed(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-padding: 10 20 10 20; -fx-background-color: #1f2a50; -fx-text-fill: white;"));
            nomBouton.setOnMouseReleased(e -> nomBouton.setStyle("-fx-font-size: 15px; -fx-padding: 10 20 10 20; -fx-background-color: #323b6f; -fx-text-fill: white;"));
            break;
        }
    }

    @Override
    public void launchApp() {
        Platform.startup(() -> {
            Stage stage = new Stage();
            try {
                this.start(stage);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @Override
    public void stopApp() {        
        Platform.exit();
    }
}
