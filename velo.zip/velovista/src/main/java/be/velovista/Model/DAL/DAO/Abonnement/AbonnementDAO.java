package be.velovista.Model.DAL.DAO.Abonnement;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import be.velovista.Model.DAL.DBConnection;

public class AbonnementDAO implements IAbonnementDAO{
  
  public AbonnementDAO(){
    DBConnection.getConnection();
  }

  public void createAbonnementTable(){
    String sqlString = "CREATE TABLE IF NOT EXISTS Abonnement (idabonnement SERIAL PRIMARY KEY, nomabonnement VARCHAR(50), prixabonnement decimal(10,2));";

      try(PreparedStatement pstat =  DBConnection.conn.prepareStatement(sqlString)){
        pstat.executeUpdate();
      }
      catch(SQLException e){
        System.out.println(e.getMessage());
      }
  }
}
