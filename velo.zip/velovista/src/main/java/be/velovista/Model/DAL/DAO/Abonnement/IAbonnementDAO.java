package be.velovista.Model.DAL.DAO.Abonnement;

public interface IAbonnementDAO {
  public void createAbonnementTable();
}
