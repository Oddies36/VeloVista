package be.velovista.Model.BL;

public class VeloEnfant extends Velo {

    public VeloEnfant(int idVelo, String marque, boolean disponible, String couleur, int taille, int age, double prix, String photo) {
        super(idVelo, marque, disponible, couleur, taille, age, prix, photo);
    }
    
}
