package be.velovista.Model.DAL.DAO.Velo;

import java.util.ArrayList;

import be.velovista.Model.BL.Velo;
import be.velovista.Model.BL.VeloClassique;

public interface IVeloDAO {
    public void createVeloTable();
    public int getPrixClassique();
    public int getPrixElectrique();
    public int getPrixEnfant();
    public ArrayList<Integer> getVitesses();
    public ArrayList<Velo> getListeVeloClass();
    public ArrayList<Velo> getListeVeloElec();
    public ArrayList<Velo> getListeVeloEnfant();
}
