package be.velovista.Model.BL;

public class User {
    
    private int idUser;
    private String nom;
    private String eMail;
    private String numTelephone;

    public int getIdUser() {
        return idUser;
    }
    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    public String geteMail() {
        return eMail;
    }
    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getNumTelephone() {
        return numTelephone;
    }
    public void setNumTelephone(String numTelephone) {
        this.numTelephone = numTelephone;
    }

    public User(int idUser, String nom, String eMail, String numTelephone){
        this.idUser = idUser;
        this.nom = nom;
        this.eMail = eMail;
        this.numTelephone = numTelephone;
    }
    
}
